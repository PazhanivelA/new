﻿namespace Mycalc
{
    partial class MyCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyCalc));
            this.TxtOne = new System.Windows.Forms.TextBox();
            this.TxtSecond = new System.Windows.Forms.TextBox();
            this.RbtnSum = new System.Windows.Forms.RadioButton();
            this.RbtnSubract = new System.Windows.Forms.RadioButton();
            this.RbtnMultiply = new System.Windows.Forms.RadioButton();
            this.RbtnDivide = new System.Windows.Forms.RadioButton();
            this.TxtResult = new System.Windows.Forms.TextBox();
            this.BtnResult = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtOne
            // 
            this.TxtOne.Location = new System.Drawing.Point(38, 29);
            this.TxtOne.Name = "TxtOne";
            this.TxtOne.Size = new System.Drawing.Size(111, 20);
            this.TxtOne.TabIndex = 0;
            // 
            // TxtSecond
            // 
            this.TxtSecond.Location = new System.Drawing.Point(38, 67);
            this.TxtSecond.Name = "TxtSecond";
            this.TxtSecond.Size = new System.Drawing.Size(111, 20);
            this.TxtSecond.TabIndex = 1;
            // 
            // RbtnSum
            // 
            this.RbtnSum.AutoSize = true;
            this.RbtnSum.Checked = true;
            this.RbtnSum.Location = new System.Drawing.Point(172, 30);
            this.RbtnSum.Name = "RbtnSum";
            this.RbtnSum.Size = new System.Drawing.Size(46, 17);
            this.RbtnSum.TabIndex = 2;
            this.RbtnSum.TabStop = true;
            this.RbtnSum.Text = "Sum";
            this.RbtnSum.UseVisualStyleBackColor = true;
            // 
            // RbtnSubract
            // 
            this.RbtnSubract.AutoSize = true;
            this.RbtnSubract.Location = new System.Drawing.Point(172, 53);
            this.RbtnSubract.Name = "RbtnSubract";
            this.RbtnSubract.Size = new System.Drawing.Size(62, 17);
            this.RbtnSubract.TabIndex = 3;
            this.RbtnSubract.Text = "Subract";
            this.RbtnSubract.UseVisualStyleBackColor = true;
            // 
            // RbtnMultiply
            // 
            this.RbtnMultiply.AutoSize = true;
            this.RbtnMultiply.Location = new System.Drawing.Point(172, 76);
            this.RbtnMultiply.Name = "RbtnMultiply";
            this.RbtnMultiply.Size = new System.Drawing.Size(60, 17);
            this.RbtnMultiply.TabIndex = 4;
            this.RbtnMultiply.Text = "Multiply";
            this.RbtnMultiply.UseVisualStyleBackColor = true;
            // 
            // RbtnDivide
            // 
            this.RbtnDivide.AutoSize = true;
            this.RbtnDivide.Location = new System.Drawing.Point(172, 99);
            this.RbtnDivide.Name = "RbtnDivide";
            this.RbtnDivide.Size = new System.Drawing.Size(55, 17);
            this.RbtnDivide.TabIndex = 5;
            this.RbtnDivide.Text = "Divide";
            this.RbtnDivide.UseVisualStyleBackColor = true;
            // 
            // TxtResult
            // 
            this.TxtResult.BackColor = System.Drawing.Color.DodgerBlue;
            this.TxtResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtResult.ForeColor = System.Drawing.SystemColors.Desktop;
            this.TxtResult.Location = new System.Drawing.Point(148, 142);
            this.TxtResult.Name = "TxtResult";
            this.TxtResult.ReadOnly = true;
            this.TxtResult.Size = new System.Drawing.Size(111, 13);
            this.TxtResult.TabIndex = 5;
            this.TxtResult.Visible = false;
            // 
            // BtnResult
            // 
            this.BtnResult.Location = new System.Drawing.Point(38, 136);
            this.BtnResult.Name = "BtnResult";
            this.BtnResult.Size = new System.Drawing.Size(76, 26);
            this.BtnResult.TabIndex = 6;
            this.BtnResult.Text = "Get Result";
            this.BtnResult.UseVisualStyleBackColor = true;
            this.BtnResult.Click += new System.EventHandler(this.BtnResult_Click);
            // 
            // MyCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(286, 261);
            this.Controls.Add(this.BtnResult);
            this.Controls.Add(this.TxtResult);
            this.Controls.Add(this.RbtnDivide);
            this.Controls.Add(this.RbtnMultiply);
            this.Controls.Add(this.RbtnSubract);
            this.Controls.Add(this.RbtnSum);
            this.Controls.Add(this.TxtSecond);
            this.Controls.Add(this.TxtOne);
            this.ForeColor = System.Drawing.Color.Red;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MyCalc";
            this.Text = "MyCalc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtOne;
        private System.Windows.Forms.TextBox TxtSecond;
        private System.Windows.Forms.RadioButton RbtnSum;
        private System.Windows.Forms.RadioButton RbtnSubract;
        private System.Windows.Forms.RadioButton RbtnMultiply;
        private System.Windows.Forms.RadioButton RbtnDivide;
        private System.Windows.Forms.TextBox TxtResult;
        private System.Windows.Forms.Button BtnResult;
    }
}

